function W=KPCA(kern,X, dims)
% KPCA 
%KPCA performs kernel PCA



A=kernCompute(kern,X);
[sigma, V, lambda]=ppca(A,dims);
W=V;
