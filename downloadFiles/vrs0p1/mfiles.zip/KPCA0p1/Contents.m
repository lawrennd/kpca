% KPCA toolbox
% Version 0.1		6-Jun-2005
% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% 
% DEMOILFLOW demo of KPCA with missing data on oil flow dataset
% DEMOILRECONERROR performs  missing data KPCA on oil flow for different percentages of missing data and different seeds.
% DEMTOBAMO demo of PCA with missing data on tobamovirus dataset
% KPCA performs kernel PCA
% KPCALIKEMISSING computes cross entropy between kernel and approximating matrix.
% KPCALIKEMISSINGGRAD gradient of the cross entropy w.r.t. missing data.
% KPCAMISSER randomly deletes a proportion p of entries from the data design matrix
% KPCAMISSING solves kpca missing data problem by iteratively minimising cross entropy.
% KPCANUMCOMP computes the number of principal components to be used in a
% KPCAOPTIONS sets default options for KPCA missing data problem.
% KPCAPLOTNUM A function to plot points as numbers rather than symbols.
