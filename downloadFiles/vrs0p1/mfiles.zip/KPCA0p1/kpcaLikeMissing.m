function f = kpcaLikeMissing(X,W,sigma,kern, I,npts,Dim);

% KPCALIKEMISSING computes cross entropy between kernel and approximating matrix.
%
% f = kpcaLikeMissing(X,W,sigma,kern, I,npts,Dim);

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Fri Jun  3 14:56:53 2005
% KPCA toolbox version 0.1




X=reshape(X,npts,Dim);

A=kernCompute(kern, X);
Kx =W*W'+sigma*eye(npts); 
f= +0.5*logdet(Kx)+0.5*trace(A*pdinv(Kx))-npts/2;

