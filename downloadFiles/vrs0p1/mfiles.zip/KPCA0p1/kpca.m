function W=kpca(kern,X, dims)

% KPCA performs kernel PCA
%
% W=kpca(kern,X, dims)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Fri Jun  3 14:52:48 2005
% KPCA toolbox version 0.1



A=kernCompute(kern,X);
[sigma, V, lambda]=ppca(A,dims);
W=V;
